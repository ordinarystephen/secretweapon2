# Financials Skill v1.0

## Question
Does available analysis accurately and adequately describe current economics, repayment/recovery capacity and value support?

## Owns when relevant
Financial-analysis quality/timeliness; performance; liquidity; leverage; capital structure; cash flow; debt service/repayment capacity; projections/model history; EBITDA/adjustments; maturities; EV/debt coverage; sources of repayment; C&I PSOR/SSOR; CRE NCF/NOI, DSCR, occupancy, rent/tenant economics, LTV/value coverage, reserves and financial assumptions supporting recovery.

## GRM principle
Do not assume a performing-credit financial package remains useful. Current recovery economics can matter more than legacy underwriting projections. Lack of a conventional model does not automatically make Financials N/A.

## C&I lane
As applicable assess revenue, EBITDA/margins, FCF/working capital, liquidity, leverage, FCCR/debt service, maturities/refinancing, EBITDA adjustments, projections/model updates, expected/downside cases, EV/debt coverage, repayment sources and performance versus expectations. Challenge stale assumptions, unsupported add-backs, unrealistic recovery, inconsistent balances and failure to update after deterioration.

## CRE lane
As applicable assess property performance, economic/physical occupancy, tenant concentration/lease status, collections/lease cash flow, NOI/NCF, DSCR, reserves, debt yield, LTV/value coverage, appraisal/BOV assumptions, sale/refinancing economics, carrying costs, capex/TI/leasing costs and workout sensitivities. Challenge stale values, inconsistent dates, unsupported lease-up/exit assumptions and omitted carrying costs.

## Repayment sources
Identify what actually resolves the exposure now: operations, lease cash flow, refinancing, sale, sponsor support, collateral liquidation, lease buyout, restructuring, etc. Do not preserve stale PSOR/SSOR labels merely because an old review used them.
