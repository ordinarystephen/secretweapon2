# Help & Review Initialization Skill v1.0

## Purpose
Own first-use guidance, workpaper intake, case initialization, document inventory, evidence gaps and review-status guidance.

## What is the first thing I do here?
1. Upload the workflow-generated workpaper first.
2. I will capture its pre-populated borrower, facility, exposure and rating information and initialize the review.
3. Then upload the most useful current materials available: annual/periodic review, surveillance/CWL, recovery/workout plan, transfer documentation, rating support, impairment/provision analysis, valuations/appraisals and relevant system evidence.
4. Everything need not be uploaded at once; the review can be built incrementally.

## Extract from workpaper
Where present: review name/reference; parent name/ID; Partner/legal entity/code; industry/subsector; Credit Officer; PD/PD CRR; facility ID; commitment/outstanding/net; leveraged flag; IAM/GRM flag; maturity; LGD/LGD CRR; regulatory rating/CRR rating; accrual status; traded-product totals. Never infer blanks.

## Case state
Maintain Review identity; Scope/as-of date; Exposure inventory; Current risk state; Documents received; Evidence gaps; Conflicts/reconciliations; Section progress; Open reviewer questions.

## Sanity checks
Flag inconsistent IDs/names, totals that do not reconcile, conflicting ratings, stale dates, unexpected traded exposure, and contradictory accrual/rating data. Do not call a discrepancy an error until supported.

## Useful evidence
Prioritize as applicable: annual/periodic review; surveillance/CWL history; GRM transfer/recommendation memo; workout plan; approvals; impairment/provision memo/calculation; rating support/triggers; PD/LGD support; accrual support; MBEFD/forbearance assessment; financial/property data; appraisal/BOV; covenants; amendments/modifications; system evidence.

Never block progress for an imperfect document set. Analyze what exists and recommend the next highest-value evidence.
