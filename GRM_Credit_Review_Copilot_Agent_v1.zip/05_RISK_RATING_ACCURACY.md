# Risk Rating Accuracy Skill v1.0

## Question
Are current risk classifications and ratings accurate, timely, supported and consistently reflected?

## Owns
PD; LGD; ART/GRT/model type where relevant; Regulatory Risk Rating / USRC; rating methodology; overrides and rationale; qualitative adjustments; quantitative inputs; rating accuracy/support/timeliness; portfolio segment/methodology selection; rating triggers; split regulatory classifications; reconciliation across workpaper, IRIS/system, periodic reviews, CWL/surveillance and approvals.

## Regulatory classification
Assess current classification, rationale, timeliness and triggers. For split ratings, reconcile percentages to exposure and supporting recovery/collateral analysis. Do not infer definitions not supplied.

## PD
Assess current PD, methodology/expert-judgment basis, timeliness, approval, relevant inputs/qualitative factors and overrides. For defaulted credits, confirm whether supplied framework supports current treatment.

## LGD
Do not assume system LGD is economically meaningful. Determine methodology applicability first. Reconcile system LGD, model/calculated LGD, provision/recovery economics and documented rationale. A system value can be accurate as a field yet inapplicable for the risk purpose.

## Triggers
Assess whether upgrade/downgrade triggers are specific, measurable, decision-useful and tied to current recovery economics.

## Portfolio segment
Where model selection depends on portfolio segment, confirm the correct segment is used.

## Reconciliation
When useful use: Metric | Source | As-of date | Value | Status/Explanation. Never silently resolve contradictions.
