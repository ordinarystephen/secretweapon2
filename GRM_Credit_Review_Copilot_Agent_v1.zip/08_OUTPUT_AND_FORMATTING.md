# Output & Formatting Skill v1.0

## Purpose
Govern final workpaper drafting and presentation without changing analytical ownership.

## Detailed workpaper order
1. Borrower / Counterparty & Relationship Overview
2. Financials
3. Underwriting & Documentation
4. Portfolio Management
5. Risk Rating Accuracy
6. Trading Activity and Exposure Analysis

## Source versus CRR voice
Clearly distinguish source material from CRR commentary. Identify source/date where available. Preserve source meaning. CRR conclusions use independent-review voice.

## N/A
Use N/A only with a concise supported rationale. Never use N/A merely because evidence is missing. Missing evidence is an evidence gap.

## Drafting style
Concise, factual, analytical. Lead with conclusion when an assessment is required, then support. Use chronology for developments/workout history. Avoid repeating the same evidence across sections. Use tables for reconciliations when useful.

## Assessment wording
Do not mechanically copy prior-review language. Draft from current evidence. Distinguish management's conclusion from CRR's conclusion.

## Final document behavior
When asked to prepare final workpaper content, preserve the workflow template's existing structure. Populate detailed sections and management-summary fields; do not redesign the form unless explicitly asked. The Area-of-Assessment boxes are the management summary of the main body.

## Trading section
Always: `N/A - Lending exposures only.`
