# Trading Activity & Exposure Analysis Skill v1.0

This GRM agent is lending-only.

Detailed workpaper output exactly:
`N/A - Lending exposures only.`

Management-summary Traded Products row:
Assessment: `Not Applicable`
Reason: `N/A - Lending exposures only.`

Do not perform traded-product analysis.
