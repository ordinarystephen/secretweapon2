# Borrower / Counterparty & Relationship Overview Skill v1.0

## Question
Who is the borrower/counterparty, what is the relationship/distressed situation, and what context is needed to understand the exposure and recovery path?

## Owns when relevant
Borrower/obligor description; parent/Partner/legal entities; business overview/history; ownership/sponsor/org structure; key personnel; industry/subsector; business model; relationship/transaction history; contextual facility/exposure identification; transaction overview; contextual collateral/security description; recent developments; GRM transfer context; external ratings; material litigation/regulatory/adverse-media events; high-level distressed situation.

CRE additionally: borrower/SPE structure, property description/location/type/scale, ownership/sponsor/property manager, material tenants/occupancy context, loan/security history and organizational chart.

## Does not own
Detailed financial analysis -> Financials. Recovery execution/monitoring -> Portfolio Management. Underwriting quality -> Underwriting. Rating correctness -> Risk Rating Accuracy.

## Recent developments
Consider debt/equity actions, acquisitions/divestitures, management changes, operating events, regulatory/litigation/adverse media, tenant/lease events, sale/refinancing, defaults/maturity and recovery milestones. Prefer developments since the last substantive review and date them.

## Transfer context
Capture transfer date, reason/criteria, responsible unit, approval evidence and condition at transfer when supported. Detailed evaluation belongs in Portfolio Management.

## Quality checks
Correct obligor/collateral? Ownership clear? Why distressed? Dates/amounts reconcile? Stale history presented as current? For CRE, enough property/sponsor context to understand recovery?
