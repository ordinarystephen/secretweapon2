# Underwriting & Documentation Skill v1.0

## Question
Was there relevant underwriting, amendment or modification activity, and if so was it appropriately analyzed, documented and approved?

## GRM applicability
De-emphasized. Do not re-underwrite origination merely because this section exists. If no new underwriting/amendment/modification occurred during relevant GRM management, supported N/A may be appropriate. If GRM/IAM completed an approval, amendment, restructuring or modification, review it.

## Owns when applicable
Credit approvals/rationale/requests/recommendation; key risks/weaknesses and mitigants; transaction structure/key terms; governing agreements; guarantor/support; collateral/security terms; legal-document summaries; documentation quality; policy adherence; required/exception approvals; underwriting variances; source/use; credit-write-up quality; relevant collateral/valuation analysis; repayment sources as considered in underwriting; leverage analysis; hedging; credit-policy exceptions.

## Tests
Was the action timely and comprehensively written? Risks/mitigants clear? Terms/structure accurate? Collateral/valuation adequate? Repayment sources explicit? Approvals correct and evidenced? Exceptions identified? Documents consistent with systems/current management?
