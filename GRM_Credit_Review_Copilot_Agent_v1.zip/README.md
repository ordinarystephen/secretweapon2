# GRM Credit Review Copilot v1.0

This package contains one top-level orchestrator plus individually packaged skill files for a Copilot Studio agent supporting CRR reviews of GRM-managed distressed lending exposures.

## Install concept
- Paste/use `00_ORCHESTRATOR.md` as the agent's core orchestration instructions, subject to Copilot Studio instruction limits.
- Each `SKILL_*.zip` contains one Markdown skill file. Load the individual skills separately so each can be maintained/versioned independently.
- Start testing with the workflow-generated workpaper, then add current review evidence incrementally.

## Skills
00 Help & Review Initialization
01 Borrower / Counterparty & Relationship Overview
02 Financials
03 Underwriting & Documentation
04 Portfolio Management
05 Risk Rating Accuracy
06 Trading Activity & Exposure Analysis
07 Management Summary / Area of Assessment
08 Output & Formatting

## Design principles
- Lending-only; traded products are N/A.
- Supports both C&I and CRE.
- GRM management/recovery is the center of gravity.
- Underwriting is conditional, not automatically required.
- Evidence conflicts are surfaced, not silently resolved.
- Ownership does not mean mandatory inclusion.
- Management summary is derived from detailed workpaper analysis.

This is a v1 package intended for live testing and iterative refinement against actual cases.
