# Portfolio Management Skill v1.0

## Question
Is GRM managing the distressed asset appropriately, timely and with a supportable recovery strategy?

## Primary ownership
This is the center-of-gravity skill.

## Owns
Transfer to GRM/IAM; transfer rationale/approval; workout/recovery plan; de-risking strategy; milestones/timeframes; tactical position; challenges/risks/dependencies; strategy changes; periodic/annual reviews; surveillance/CWL monitoring; monitoring frequency/timeliness; collateral monitoring; financial-reporting monitoring; covenant monitoring; information sufficiency; IRIS/system observations; watchlist status; actions/issues/escalations/follow-up; impairment/provision analysis and monitoring; accrual status; charge-offs/write-downs; MBEFD/forbearance assessment; approvals; monitoring controls; recovery progress; valuation refreshes as management controls.

## Transfer
Assess evidence of obligor, exposure, transfer criterion/reason and required approval/sign-off. Determine timeliness only from supplied requirements/evidence.

## Workout/recovery strategy
Look for transaction background/issues, current exposure, strategy/tactics, milestones, financial/action triggers, timing and implementation. Test whether strategy is current, internally consistent and directed toward recoverable value. Compare alternatives when management did so; do not invent economics.

## Monitoring
Assess periodic-review timeliness/quality; surveillance/CWL cadence; collateral/covenant monitoring; current financial/property information; system accuracy; actions/escalations; milestone slippage and responses. IRIS/system observations focus on accuracy, currency, reconciliation and nuances worth documenting.

## Impairment/provisions
Assess whether analysis was performed when applicable; methodology/evidence supplied; current facts and assumptions; timeliness; approval; reconciliation to exposure/value; refresh after material information. Do not calculate a required provision unless methodology and inputs support it.

## Accrual / distressed designations
Assess accuracy/timeliness of accrual/non-accrual and relevant default, past-due, forbearance/MBEFD designations using supplied policy evidence. Reconcile documents and systems.

## CRE
Emphasize property/collateral management, appraisal/BOV refresh, occupancy/tenancy, carrying costs, sale/refinancing/DIL/receivership/lease-buyout strategy where relevant, sponsor cooperation and milestones.

## C&I
Emphasize restructuring/workout strategy, liquidity/cash preservation, collateral/value, sponsor support, refinancing/sale, operating milestones and recovery economics.
