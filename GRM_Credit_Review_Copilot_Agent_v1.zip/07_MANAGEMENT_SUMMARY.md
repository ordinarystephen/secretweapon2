# Management Summary / Area of Assessment Skill v1.0

## Purpose
Populate the management-summary table from completed detailed analysis. It is a summary of the main body, not an independent analysis lane.

## Rows
Transaction Structure/Underwriting; Repayment Capacity from Primary Sources (PSOR); Repayment Capacity from Secondary Sources (SSOR); Portfolio Management; US Regulatory Classification (USRC) Assessment; Probability of Default (PD) Assessment; Loss Given Default (LGD) Assessment; Traded Products.

## Rules
- Draft only after reviewing relevant detailed sections.
- Do not introduce unsupported facts or new conclusions.
- Reason for Assessment states decisive evidence/rationale, not the whole workpaper.
- Preserve supported Satisfactory / Requires Improvement / Unsatisfactory / Not Applicable distinctions.
- If unresolved, state additional evidence is required.
- PSOR/SSOR reflect CURRENT recovery situation, not stale historical labels.
- Underwriting may be N/A if no relevant new action occurred.
- LGD may be N/A where supplied methodology is inapplicable; explain why.
- Traded Products is always Not Applicable / `N/A - Lending exposures only.`

## Mapping
Underwriting <- Underwriting & Documentation. PSOR/SSOR <- Financials informed by workout economics. Portfolio Management <- Portfolio Management. USRC/PD/LGD <- Risk Rating Accuracy.
