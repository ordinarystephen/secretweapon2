# Sentinel Standard IB — Simplified Baseline

## Purpose

This is an **A/B-test sibling template**, not a replacement for the current `ib_template`.

It keeps the existing Sentinel runtime contract and the current document/output infrastructure, while replacing the 89-question Standard IB criteria architecture with a deliberately lean baseline.

## What changed

- Standard IB criteria reduced to **28 questions** across the same six work-paper sections.
- No `question_library.yaml`.
- No GRM criteria set.
- No `review_plan`.
- No `work_product_plan`.
- No `review_level_outputs` / feeder graph.
- No `ownership_boundaries` or `ownership_principles`.
- No `policy_check` questions.
- No `governing_guidance` metadata.
- No question `pattern`, `shared_check`, `known_gap`, or `rating_input` metadata.
- Rating concurrence fills are retained so `PD-CRR`, `LGD-CRR`, and `RegRtg-CRR` can still be populated.
- The existing `section_profile.yaml`, `workpaper_spec.yaml`, input class, prompts, and attribute vocabulary are copied unchanged to isolate the criteria-set change.

## Intentional design choices

1. **Extraction stays extraction.** Business overview and recent developments are explicit `stated_fact` tasks and ask for source wording to be preserved.
2. **Judgment is materiality-focused.** Criteria ask for material risks, drivers, implications, and CRR conclusions rather than exhaustive inventories.
3. **Policy is deferred.** Approval/documentation can identify evident gaps, but no policy thresholds or delegated-authority tests are run.
4. **No AI self-review tier.** The first experiment should test whether simpler primary analysis produces a cleaner work paper before adding another model pass.
5. **No Joseph-derived analytical framework yet.** This is the clean baseline. Add analytical primitives only after observing this run.

## Porting

Copy `ib_template_simplified/` beside the current template:

```text
crr/templates/
  ib_template/
  ib_template_simplified/
```

Select `ib_template_simplified` explicitly in the review config/UI. Do **not** replace `ib_template` yet.

The template's criteria-set selector is:

```yaml
selects_when: review_family == corporate_lending
```

The existing attribute defaults already resolve `review_family` to `corporate_lending`.

## What to compare

Run the **same input package** through the existing and simplified templates. Compare:

- useful signal vs. noise;
- factual accuracy;
- evidence/citation quality;
- duplicated content;
- unsupported conclusions;
- section coherence;
- whether the output feels like CRR rather than generic credit summarization;
- run time / model-call volume;
- reviewer editing effort.

Do not score the simplified baseline down merely because the topics table is not automatically populated: `review_level_outputs` were intentionally removed from this experiment. Judge the six section bodies and rating fills first.

## Likely next iteration

After the baseline run:

1. Fix only concrete failures observed in the simplified criteria.
2. Decide whether any removed runtime metadata is actually necessary.
3. Introduce the Joseph-derived analytical framework beneath the criteria.
4. Only then revisit reusable modules / impaired-credit overlays / portfolio read-across.
