# CRR Style Pack v1: cover note

**What this is.** A directional representation of the content CRR's use-case configuration will need to carry for workpaper drafting and checking: structure, terminology, assessment language, evidence conventions, writing rules, and word lists. It shows what the standards contain and how they group. It is not a format specification. Express it however Use-case Configuration expects packs to be expressed; the grouping and the ids are the part worth preserving.

**What it is not.** Not adopted standards. Entries marked `pending_adjudication` are placeholders for decisions the CRR team makes after the full-corpus analysis. Not a linter design. Where a rule is measurable, the metric name is given so the two sides can agree on vocabulary, but thresholds are empty and the checking mechanism is yours to decide.

**Where the content comes from.** Two sources. The historical workpaper corpus, analyzed by CRR's extraction tool, gives the evidence: which constructions, terms, and structures are actually in use, and how they vary by author and rating. The CRR team then decides what becomes canonical, acceptable, or avoided. The pack is the output of that decision, and it will be regenerated from the same decision record each time it changes.

**What matters first.** Three files carry most of the value and should be the first conversation: `terminology.yaml`, `assessment_language.yaml`, and `writing_rules.yaml` with its `lexicons.yaml`. `structure.yaml` and `evidence_conventions.yaml` are stable and low-risk. Derived data (typical section lengths, representative examples) is deliberately outside the versioned pack; a sample sits in `derived/` to show the shape.

**Questions for the platform side.**

1. How does Use-case Configuration expect a pack like this to be expressed and loaded, and who owns the loading step?
2. When a reviewer's ruling records a standards version, what does it resolve to, and is the manifest here a workable target?
3. Is prompt assembly per section a platform service or a use-case responsibility? The answer changes which files need machine-tight patterns and which can stay human-readable.
4. What happens when a pack fails validation: refuse to load, load with warnings, or fall back to the prior version?
5. Where do word lists that the business edits often (vague terms, substitutions) live so that changes don't require a release?

**Contact.** Stephen Costello, Credit Risk Review.
