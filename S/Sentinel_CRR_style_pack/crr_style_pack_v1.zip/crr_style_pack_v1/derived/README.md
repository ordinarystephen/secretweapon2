# derived/ (not part of the standard)

Data regenerated from each corpus analysis run. It informs the standard (thresholds, typical shapes, examples) but is not itself a rule, so it is not versioned with the pack.

- `composition_baseline.yaml` — typical section lengths, figure and table counts, and sentence metrics per section (median and interquartile range). Used to set the null thresholds in `writing_rules.yaml`.
- `representative_units.yaml` — pointers (by unit id, no text) to sections and grid justifications the corpus tool scored as representative, awaiting SME review. Used for examples in the written guide and for grounding.

Sample shape of `composition_baseline.yaml`:

```yaml
run_id: null
sections:
  SEC-FIN:
    words: {median: null, p25: null, p75: null}
    figures: {median: null}
    tables: {median: null}
    passive_rate: {median: null, p75: null}
    words_per_sentence: {median: null, p90: null}
```
