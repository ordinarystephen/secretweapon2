# CRR Style Pack v1 (directional)

A directional representation of CRR's language standards and house writing style in a form that could be loaded as configuration. Read `COVER_NOTE.md` first.

## Files

| File | Edited by | Cadence | What it holds |
|---|---|---|---|
| `manifest.yaml` | CRR analytics | each release | version, what the pack was derived from, file list |
| `structure.yaml` | SME / RIC | rarely | sections, subsections, review questions each section answers, grid topics, rating scale |
| `terminology.yaml` | SME | grows over time | one entry per concept: canonical term, variants with status, definition, source |
| `assessment_language.yaml` | CRR team | after adjudication | how CRR states each kind of assessment; hedging; how language shifts by rating |
| `evidence_conventions.yaml` | SME | rarely | how each source type is cited |
| `writing_rules.yaml` | CRR analytics | rarely | the prescriptive writing standard, one rule per entry |
| `lexicons.yaml` | anyone on the team | often | word lists the rules refer to |
| `schemas/` | CRR analytics | with the pack | one JSON schema as the pattern; the rest follow it |
| `derived/` | generated | each corpus run | NOT part of the standard: typical lengths, representative examples |

## Conventions

- Every entry has an `id` (stable, never reused), a `scope` (section ids, grid topic ids, `grid`, or `all`), and a `status` (`adopted`, `pending_adjudication`, `retired`).
- Rules and conventions carry `enforcement`: `must`, `should`, or `info`.
- `source` is a short free-text pointer to where the entry came from (a decision record row, a policy section, a corpus finding). One field, not a structure.
- Constructions carry a human-readable `template` and, where a check needs it, a machine `pattern`. Only the pattern is meant to be matched.
- Each word list lives in exactly one file. Other files refer to it by name.
- No borrower, counterparty, or person names anywhere.

## How it is produced

Corpus analysis (evidence) plus the CRR decision record (choices) generate this pack and the written style guide together, so the two never drift.
