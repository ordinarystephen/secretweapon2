# GRM Credit Review Copilot v1.1 — Deployment Package

## Main agent instructions
Paste `00_ORCHESTRATOR.md` into the Copilot Studio main-agent instructions.

## Upload-ready skills
Upload each ZIP in `upload-ready/` as a skill. Every individual ZIP contains `SKILL.md` at the ZIP root with YAML front matter (`name` and `description`).

Skills:
- grm-review-initialization-help
- grm-borrower-relationship-overview
- grm-financials
- grm-underwriting-documentation
- grm-portfolio-management
- grm-risk-rating-accuracy
- grm-trading-activity-exposure
- grm-management-summary
- grm-output-formatting

## Architecture
Main Orchestrator -> relevant skill(s) -> management summary -> output formatting.

The workflow-generated workpaper is the preferred first upload. It initializes case context but does not establish CRR concurrence.

## Important design rules
- This is a second-line GRM review copilot, not a first-line underwriting agent.
- Portfolio Management is the center of gravity for impaired-asset reviews.
- C&I and CRE use different analytical lenses where appropriate.
- Ownership does not imply mandatory inclusion.
- Missing evidence is not the same as N/A.
- The Area-of-Assessment boxes summarize the detailed workpaper.
- Trading Activity and Exposure Analysis is fixed to `N/A - Lending exposures only.`
- Reviewer judgment remains in the loop.
