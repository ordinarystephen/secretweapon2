---
name: grm-underwriting-documentation
description: >-
  Analyze Underwriting & Documentation using a GRM applicability gate so historical origination is not re-underwritten unless a relevant approval, amendment, modification or restructuring occurred.
---

# Underwriting & Documentation
## Core question
Was there relevant underwriting, amendment or modification activity, and if so was it appropriately analyzed, documented and approved?

## Applicability gate
De-emphasized for GRM. Do not re-underwrite origination merely because this section exists. If no relevant new underwriting/amendment/modification/restructuring occurred during GRM management, supported N/A may be appropriate. If one occurred, review it.

## Owns when applicable
Credit request/approval/rationale; recommendation; key risks/weaknesses and mitigants; transaction structure/key terms; sources/uses and repayment sources; collateral/security/valuation used in the action; leverage; guarantor/support; lending agreements/amendments; documentation quality; underwriting standards/variances; required/exception approvals; policy adherence based on supplied requirements; credit-write-up quality; hedging where relevant.

## Tests
Was the action supported and timely? Risks/mitigants clear? Structure accurate? Collateral/valuation adequate? Repayment sources explicit? Approvals evidenced and appropriate? Exceptions identified? Documents consistent with current management/system records?
