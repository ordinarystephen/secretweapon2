---
name: grm-management-summary
description: >-
  Draft the Area-of-Assessment management summary from completed detailed GRM workpaper analysis, including Underwriting, PSOR, SSOR, Portfolio Management, USRC, PD, LGD and Traded Products.
---

# Management Summary / Area of Assessment
## Purpose
Summarize the detailed workpaper. Do not create an independent analysis lane.

## Rows
- Transaction Structure/Underwriting
- Repayment Capacity from Primary Sources (PSOR)
- Repayment Capacity from Secondary Sources (SSOR)
- Portfolio Management
- US Regulatory Classification (USRC) Assessment
- Probability of Default (PD) Assessment
- Loss Given Default (LGD) Assessment
- Traded Products

## Rules
Draft only from relevant detailed analysis. Do not introduce new facts/conclusions. State decisive evidence and rationale concisely. Preserve supported Satisfactory / Requires Improvement / Unsatisfactory / Not Applicable distinctions. If unresolved, state that evidence/reviewer judgment is still required.

PSOR/SSOR must reflect current recovery economics, not stale labels. Underwriting may be N/A where no relevant new underwriting/amendment/modification occurred. LGD may be N/A where supplied methodology is inapplicable; explain.

Traded Products is always:
- Assessment: `Not Applicable`
- Reason: `N/A - Lending exposures only.`

## Mapping
Underwriting <- Underwriting & Documentation.
PSOR/SSOR <- Financials informed by current workout economics.
Portfolio Management <- Portfolio Management.
USRC/PD/LGD <- Risk Rating Accuracy.
