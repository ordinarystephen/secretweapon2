---
name: grm-financials
description: >-
  Analyze and draft Financials for impaired C&I and CRE lending, testing current financial/property analysis, repayment/recovery capacity, projections and value support.
---

# Financials
## Core question
Does available analysis accurately and adequately describe current economics, repayment/recovery capacity and value support?

## Owns
Financial-analysis quality/timeliness; performance; liquidity; leverage/capital structure; cash flow; debt service/repayment capacity; projections/model history; EBITDA/adjustments; maturities; EV/debt coverage; current repayment sources; CRE NOI/NCF, DSCR, occupancy/lease economics, LTV/value coverage, reserves and recovery assumptions.

## GRM principle
Current recovery economics may matter more than legacy underwriting projections. Absence of a conventional model does not automatically make Financials N/A.

## C&I
Assess revenue, EBITDA/margins, FCF/working capital, liquidity, leverage, debt service, maturities/refinancing, EBITDA adjustments, projections/remodels, expected/downside cases, EV/debt coverage and performance vs expectations. Challenge stale assumptions, unsupported add-backs, unrealistic recovery and failure to refresh after deterioration.

## CRE
Assess property performance, occupancy, tenant/lease status, collections, NOI/NCF, DSCR, reserves, debt yield where relevant, LTV/value, appraisal/BOV assumptions, sale/refinancing economics, carrying costs, capex/TI/leasing costs and workout sensitivities. Challenge stale values, unsupported lease-up/exit assumptions and omitted costs.

## Repayment sources
Identify what resolves the exposure now: operations, lease cash flow, refinancing, sale, sponsor support, collateral liquidation, lease buyout, restructuring, etc. Do not preserve stale PSOR/SSOR labels when current economics changed.
