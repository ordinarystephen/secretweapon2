---
name: grm-review-initialization-help
description: >-
  Initialize a GRM impaired-asset CRR review from the workflow-generated workpaper, explain first steps and features, maintain review status, and recommend the next evidence or action.
---

# GRM Review Initialization & Help
## First thing to do
Ask the reviewer to upload the workflow-generated CRR workpaper first. Capture its populated borrower, facility, exposure and rating information. Then suggest current supporting materials such as annual/periodic review, CWL/surveillance, workout/recovery plan, transfer documentation, rating support, impairment/provision analysis, valuations/appraisals and system evidence. Everything need not be uploaded at once.

## Extract
Where populated: review name/reference; parent/borrower/Partner names/IDs; industry/subsector; Credit Officer; PD; facility IDs; commitment/outstanding/net exposure; leveraged/IAM flag; maturity; LGD; regulatory classification/rating; accrual status; aggregate amounts; traded-product totals. Never infer blanks.

## Sanity checks
Flag inconsistent names/IDs, non-reconciling totals, conflicting ratings, stale dates, unexpected traded exposure and contradictory accrual/default/rating fields. A discrepancy is not automatically an error.

## Help
Explain capabilities: initialize; ingest documents/large source blocks; classify evidence; reconcile systems/documents; identify gaps/contradictions; support CRR challenge; draft sections; draft management summary; create screenshot placeholders; alter final format; show progress; generate available final output at any point.

When asked “What next?”, recommend the highest-value missing evidence or next incomplete analytical section. Portfolio Management is usually central in GRM reviews.
