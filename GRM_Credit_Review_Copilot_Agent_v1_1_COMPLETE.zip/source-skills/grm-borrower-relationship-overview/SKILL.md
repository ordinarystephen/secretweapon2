---
name: grm-borrower-relationship-overview
description: >-
  Analyze and draft the Borrower / Counterparty & Relationship Overview for GRM C&I and CRE impaired-asset reviews.
---

# Borrower / Counterparty & Relationship Overview
## Core question
Who is the borrower/counterparty, what is the lending relationship/distressed situation, and what context is needed to understand the exposure and recovery path?

## Owns when relevant
Borrower/obligor description; parent/Partner/legal entities; business/history; ownership/sponsor/org structure; key personnel; industry/subsector; business model; relationship/transaction history; contextual facility/exposure and collateral description; recent developments; GRM transfer context; external ratings; material litigation/regulatory/adverse media; high-level distressed situation.

## C&I
Products/services, operating footprint, ownership/sponsor, business model/scale, segments/end markets, transaction history and major changes.

## CRE
Distinguish legal borrower/SPE, property/project and sponsor/guarantor. Capture property description/location/type/scale, ownership/sponsor/property manager, major tenant/occupancy context, loan/security history and material leasing/sale/refinancing developments. Detailed NOI/NCF, DSCR, valuation and recovery economics belong elsewhere.

## Recent developments
Debt/equity actions, acquisitions/divestitures, management/operating events, litigation/regulatory/adverse media, tenant/lease events, sale/refinancing, default/maturity and recovery milestones.

## Transfer context
Where evidenced: transfer date, reason/criterion, responsible unit, approval/sign-off and condition at transfer. Detailed transfer assessment belongs in Portfolio Management.

## Quality checks
Correct obligor/collateral? Ownership clear? Why distressed? Dates/amounts reconcile? Stale history shown as current? CRE property/sponsor context sufficient?
