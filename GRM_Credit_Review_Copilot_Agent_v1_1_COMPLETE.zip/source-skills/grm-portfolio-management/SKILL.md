---
name: grm-portfolio-management
description: >-
  Assess and draft Portfolio Management for GRM impaired assets, including transfer, workout/recovery strategy, monitoring, collateral, impairment/provision, accrual, forbearance/MBEFD and recovery execution.
---

# Portfolio Management
## Core question
Is GRM managing the distressed asset appropriately, timely and with a supportable recovery strategy?

## Owns
Transfer to GRM/IAM; transfer rationale/approval; workout/recovery plan; de-risking strategy; milestones/timeframes; tactics; risks/dependencies; strategy changes; annual/periodic reviews; CWL/surveillance; monitoring frequency/timeliness; collateral monitoring; financial-reporting monitoring; covenants; information sufficiency; IRIS/system observations; watchlist; actions/issues/escalations/follow-up; impairment/provision analysis/monitoring; accrual status; charge-offs/write-downs; MBEFD/forbearance; approvals; monitoring controls; recovery progress; valuation refreshes.

## Transfer
Assess obligor/exposure, transfer criterion/reason, timing and required approval using supplied requirements/evidence.

## Workout/recovery plan
Look for background/issues, current exposure, strategy/tactics, milestones, action triggers, timing and implementation. Test whether current, internally consistent, supported and progressing. Compare alternatives only when evidence supports them.

## Monitoring
Assess periodic-review quality/timeliness; CWL cadence; collateral/covenant monitoring; current financial/property information; system accuracy; actions/escalations; milestone slippage. IRIS observations focus on what the reviewer sees: accuracy, currency, reconciliation and nuances requiring documentation—not a description of IRIS.

## Impairment/provision
Assess methodology/evidence, current facts/assumptions, timeliness, approval, reconciliation to exposure/value and refresh after material information. Do not invent a required provision.

## Accrual / distressed designations
Assess accrual/non-accrual and relevant default, past-due, forbearance/MBEFD designations against supplied policy evidence. Reconcile documents/systems.

## CRE
Emphasize property/collateral management, valuation refresh, occupancy/tenancy, carrying costs, sale/refinancing/other recovery path, sponsor cooperation and milestones.

## C&I
Emphasize restructuring/workout, liquidity/cash preservation, collateral/value, sponsor support, refinancing/sale, operating milestones and recovery economics.
