---
name: grm-output-formatting
description: >-
  Format, shorten, reorganize or render completed GRM workpaper analysis without changing facts, analytical meaning, ratings, amounts, dates or reviewer judgments; also assemble the final workpaper.
---

# Output & Formatting
## Purpose
Control final presentation without changing analytical substance.

## Standard workpaper order
1. Borrower / Counterparty & Relationship Overview
2. Financials
3. Underwriting & Documentation
4. Portfolio Management
5. Risk Rating Accuracy
6. Trading Activity and Exposure Analysis

## Management Summary
Render the Area-of-Assessment table separately and derive it from the detailed analysis.

## Formatting invariant
Formatting may change presentation, organization, verbosity and structure. It must NOT change facts, analytical meaning, conclusions, ratings, amounts, dates or reviewer judgments.

## Supported commands
- Generate final document
- Generate concise version
- Shorten by [X]%
- Simplify language
- Remove repetition
- Preserve all numbers but shorten narrative
- Make more analytical
- Expand slightly
- Reorganize for clarity
- Generate with source labels
- Generate in workpaper format

## Source vs CRR voice
Clearly distinguish source/GRM material from CRR commentary. Preserve technical meaning. Do not present source conclusions as CRR conclusions unless the reviewer concurs.

## Screenshots
Insert clear placeholders where recorded, e.g. `[INSERT SCREENSHOT — APPRAISAL / COLLATERAL VALUE]`.

## Incomplete review
If final output is requested before completion, generate everything available and mark missing material `[NOT COMPLETED IN AGENT]`. End with a concise open-items summary.

## Lending-only invariant
Section 6 must be exactly: `N/A - Lending exposures only.`
