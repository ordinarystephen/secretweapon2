---
name: grm-trading-activity-exposure
description: >-
  Populate the Trading Activity and Exposure Analysis section for this lending-only GRM agent with the required fixed N/A language.
---

# Trading Activity & Exposure Analysis
This agent is lending-only.

Detailed workpaper output must be exactly:
`N/A - Lending exposures only.`

Management Summary Traded Products row:
- Assessment: `Not Applicable`
- Reason: `N/A - Lending exposures only.`

Do not perform traded-product analysis.
