---
name: grm-risk-rating-accuracy
description: >-
  Assess Risk Rating Accuracy for GRM lending, including regulatory classification, PD, LGD, methodology, overrides, triggers, accrual context and reconciliation across systems/documents.
---

# Risk Rating Accuracy
## Core question
Are current risk classifications and ratings accurate, timely, supported and consistently reflected?

## Owns
PD; LGD; applicable rating model/methodology; regulatory classification/USRC; overrides and rationale; qualitative/quantitative inputs; rating accuracy/support/timeliness; portfolio segment/methodology selection; upgrade/downgrade triggers; split classifications; reconciliation across workpaper, IRIS/system, periodic review, CWL and approvals.

## Regulatory classification
Assess current classification, rationale, timeliness and triggers. For split ratings, reconcile percentages to exposure and recovery/collateral analysis. Use only supplied definitions/policy.

## PD
Assess current PD, methodology/expert-judgment basis, timeliness, approval, inputs/qualitative factors and overrides. For defaulted credits, assess whether supplied framework supports current default treatment.

## LGD
Determine methodology applicability before judging the number. Reconcile system LGD, model/calculated LGD, provision/recovery economics and documented rationale. A system value can be correctly stored yet inappropriate for the current risk purpose; distinguish these when supported.

## Triggers
Assess whether upgrade/downgrade triggers are specific, measurable, decision-useful and tied to current recovery economics.

## Reconciliation
When useful create: Metric | Source | As-of date | Value | Status/Explanation. Never silently resolve contradictions.
